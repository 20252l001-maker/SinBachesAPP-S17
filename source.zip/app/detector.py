"""Inferencia real YOLOv8s ONNX; preprocesado letterbox y NMS explícitos."""
import hashlib
import io
import json
from pathlib import Path
import threading
import time
import warnings
import numpy as np
import onnxruntime as ort
from PIL import Image, ImageOps, UnidentifiedImageError

Image.MAX_IMAGE_PIXELS = 12_000_000


def decode_image(data):
    if not data or len(data) > 5*1024*1024:
        raise ValueError('La imagen debe ocupar entre 1 byte y 5 MB')
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(data)) as img:
                if img.format not in ('JPEG', 'PNG'):
                    raise ValueError('Solo JPEG o PNG')
                if img.width < 32 or img.height < 32 or img.width*img.height > 12_000_000:
                    raise ValueError('Dimensiones fuera de 32 píxeles a 12 megapíxeles')
                img.load()
                return ImageOps.exif_transpose(img).convert('RGB')
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError, Image.DecompressionBombWarning) as exc:
        raise ValueError('Archivo de imagen inválido o demasiado grande') from exc


def iou(a, b):
    x1, y1 = max(a[0], b[0]), max(a[1], b[1])
    x2, y2 = min(a[2], b[2]), min(a[3], b[3])
    inter = max(0, x2-x1)*max(0, y2-y1)
    union = max(0, a[2]-a[0])*max(0, a[3]-a[1])+max(0, b[2]-b[0])*max(0, b[3]-b[1])-inter
    return inter/union if union > 0 else 0.0


def nms(boxes, scores, threshold=.45, limit=100):
    order = np.argsort(-scores, kind='stable').tolist()
    keep = []
    while order and len(keep) < limit:
        idx = order.pop(0)
        keep.append(idx)
        order = [j for j in order if iou(boxes[idx], boxes[j]) <= threshold]
    return keep


class Detector:
    def __init__(self, path='models/pothole.onnx', manifest='models/model.json'):
        model = Path(path)
        info = json.loads(Path(manifest).read_text(encoding='utf-8'))
        actual = hashlib.sha256(model.read_bytes()).hexdigest()
        if actual != info['sha256']:
            raise RuntimeError('La huella del modelo no coincide con el manifiesto')
        options = ort.SessionOptions()
        options.intra_op_num_threads = 1
        options.inter_op_num_threads = 1
        self.session = ort.InferenceSession(str(model), sess_options=options, providers=['CPUExecutionProvider'])
        if self.session.get_inputs()[0].shape != [1, 3, 640, 640]:
            raise RuntimeError('Forma de entrada de modelo inesperada')
        self.info = info
        self.lock = threading.Lock()

    def predict(self, data, confidence=.25):
        started = time.perf_counter()
        image = decode_image(data)
        width, height = image.size
        scale = min(640/width, 640/height)
        nw, nh = round(width*scale), round(height*scale)
        left, top = round((640-nw)/2-.1), round((640-nh)/2-.1)
        canvas = Image.new('RGB', (640, 640), (114, 114, 114))
        canvas.paste(image.resize((nw, nh), Image.Resampling.BILINEAR), (left, top))
        tensor = np.asarray(canvas, dtype=np.float32).transpose(2, 0, 1)[None]/255
        with self.lock:
            raw = self.session.run(None, {'images': tensor})[0]
        if raw.shape != (1, 5, 8400):
            raise RuntimeError('Salida de modelo inesperada')
        pred = raw[0].T
        pred = pred[np.isfinite(pred).all(axis=1) & (pred[:, 4] >= confidence)]
        # Acota coste NMS ante un archivo adverso.
        pred = pred[np.argsort(-pred[:, 4], kind='stable')[:1000]]
        boxes = np.empty((len(pred), 4), dtype=np.float32)
        boxes[:, 0] = (pred[:, 0]-pred[:, 2]/2-left)/scale
        boxes[:, 1] = (pred[:, 1]-pred[:, 3]/2-top)/scale
        boxes[:, 2] = (pred[:, 0]+pred[:, 2]/2-left)/scale
        boxes[:, 3] = (pred[:, 1]+pred[:, 3]/2-top)/scale
        boxes[:, [0, 2]] = boxes[:, [0, 2]].clip(0, width)
        boxes[:, [1, 3]] = boxes[:, [1, 3]].clip(0, height)
        detections = [dict(label='bache', class_id=0, confidence=float(pred[k, 4]),
                           box_xyxy=[round(float(v), 2) for v in boxes[k]])
                      for k in nms(boxes, pred[:, 4]) if boxes[k, 2] > boxes[k, 0] and boxes[k, 3] > boxes[k, 1]]
        return dict(model_id=self.info['repo_id'], model_sha256=self.info['sha256'],
                    pretrained=True, image_width=width, image_height=height,
                    confidence_threshold=confidence, nms_iou=.45, detections=detections,
                    count=len(detections), inference_ms=round((time.perf_counter()-started)*1000, 3),
                    interpretation='Detección candidata; requiere revisión humana')
