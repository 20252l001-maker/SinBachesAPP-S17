import json
import math
from pathlib import Path
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone


def distance_m(lat1, lon1, lat2, lon2):
    a, b = math.radians(lat1), math.radians(lat2)
    dlat, dlon = b-a, math.radians(lon2-lon1)
    hav = math.sin(dlat/2)**2+math.cos(a)*math.cos(b)*math.sin(dlon/2)**2
    return 6371000*2*math.asin(min(1, math.sqrt(hav)))


class Store:
    def __init__(self, path):
        self.path = str(path)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS tickets (
                    id INTEGER PRIMARY KEY, lat REAL NOT NULL, lon REAL NOT NULL,
                    street TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pendiente',
                    priority TEXT NOT NULL, created TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS reports (
                    id INTEGER PRIMARY KEY, image_sha TEXT UNIQUE NOT NULL,
                    ticket_id INTEGER NOT NULL REFERENCES tickets(id), lat REAL NOT NULL,
                    lon REAL NOT NULL, prediction TEXT NOT NULL, created TEXT NOT NULL);
            ''')

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        try:
            with db:
                yield db
        finally:
            db.close()

    def add(self, sha, lat, lon, street, main_road, prediction):
        now = datetime.now(timezone.utc).isoformat()
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if db.execute('SELECT id FROM reports WHERE image_sha=?', (sha,)).fetchone():
                raise ValueError('Esta fotografía ya fue registrada')
            nearby = [dict(r) for r in db.execute("SELECT * FROM tickets WHERE status != 'reparado'")
                      if distance_m(lat, lon, r['lat'], r['lon']) <= 30]
            if nearby:
                ticket = min(nearby, key=lambda r: distance_m(lat, lon, r['lat'], r['lon']))['id']
                if main_road:
                    db.execute("UPDATE tickets SET priority='alta' WHERE id=?", (ticket,))
            else:
                ticket = db.execute('INSERT INTO tickets(lat,lon,street,priority,created) VALUES(?,?,?,?,?)',
                    (lat, lon, street, 'alta' if main_road else 'normal', now)).lastrowid
            report = db.execute('INSERT INTO reports(image_sha,ticket_id,lat,lon,prediction,created) VALUES(?,?,?,?,?,?)',
                (sha, ticket, lat, lon, json.dumps(prediction), now)).lastrowid
            return dict(report_id=report, ticket_id=ticket, grouped=bool(nearby), status='registrado')

    def list(self):
        with self.connect() as db:
            return [dict(r) for r in db.execute('''SELECT t.*, COUNT(r.id) AS reports
                FROM tickets t LEFT JOIN reports r ON t.id=r.ticket_id GROUP BY t.id ORDER BY t.id DESC LIMIT 500''')]

    def update(self, ticket, status):
        with self.connect() as db:
            cur = db.execute('UPDATE tickets SET status=? WHERE id=?', (status, ticket))
            return cur.rowcount == 1
