import hashlib
import hmac
import json
import logging
import os
from pathlib import Path
import time
from contextlib import asynccontextmanager
from typing import Annotated, Literal
from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.security import APIKeyHeader
from pydantic import BaseModel, ConfigDict
from prometheus_client import CollectorRegistry, Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from .detector import Detector
from .store import Store

log = logging.getLogger('sinbaches')
header = APIKeyHeader(name='X-API-Key', auto_error=False)
MAX_BODY = 6*1024*1024


class BodyLimit:
    def __init__(self, app): self.app = app

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http' or scope['method'] not in ('POST', 'PUT', 'PATCH'):
            return await self.app(scope, receive, send)
        parts, total = [], 0
        while True:
            message = await receive()
            if message['type'] == 'http.disconnect': return
            total += len(message.get('body', b''))
            if total > MAX_BODY:
                return await JSONResponse({'detail':'Solicitud superior a 6 MB'}, status_code=413)(scope, receive, send)
            parts.append(message.get('body', b''))
            if not message.get('more_body', False): break
        sent = False
        async def replay():
            nonlocal sent
            if not sent:
                sent = True
                return {'type':'http.request', 'body':b''.join(parts), 'more_body':False}
            return await receive()
        return await self.app(scope, replay, send)


class TicketUpdate(BaseModel):
    model_config = ConfigDict(extra='forbid')
    status: Literal['pendiente', 'validado', 'reparado']


def create_app(detector=None, db_path=None):
    key = os.environ.get('API_KEY', '')
    @asynccontextmanager
    async def lifespan(app):
        if len(key) < 32 or key.startswith('REEMPLAZAR'):
            raise RuntimeError('Configure API_KEY aleatoria de al menos 32 caracteres')
        app.state.detector = detector or Detector()
        app.state.store = Store(db_path or os.environ.get('DB_PATH', 'data/sinbaches.db'))
        yield

    app = FastAPI(title='SinBachesAPP', version='2.0.0', lifespan=lifespan,
                  docs_url=None, redoc_url=None, openapi_url=None)
    app.add_middleware(BodyLimit)
    registry = CollectorRegistry()
    requests = Counter('sinbaches_http_requests', 'Solicitudes HTTP', ['route', 'status'], registry=registry)
    duration = Histogram('sinbaches_http_seconds', 'Latencia de peticiones', ['route'], registry=registry)
    inference = Histogram('sinbaches_inference_seconds', 'Inferencia y preprocesado', registry=registry)
    detected = Counter('sinbaches_detections', 'Candidatos detectados', registry=registry)
    errors = Counter('sinbaches_inference_errors', 'Errores de inferencia', registry=registry)

    def auth(provided: str | None = Depends(header)):
        if not provided or not hmac.compare_digest(provided.encode(), key.encode()):
            raise HTTPException(401, 'API key ausente o incorrecta', headers={'WWW-Authenticate':'APIKey'})

    @app.middleware('http')
    async def monitor(request: Request, call_next):
        begin, status = time.perf_counter(), 500
        try:
            response = await call_next(request)
            status = response.status_code
            response.headers['X-Content-Type-Options'] = 'nosniff'
            response.headers['Cache-Control'] = 'no-store'
            return response
        finally:
            route = request.scope.get('route')
            label = route.path if route else 'unmatched'
            elapsed = time.perf_counter()-begin
            requests.labels(label, str(status)).inc()
            duration.labels(label).observe(elapsed)
            log.info(json.dumps(dict(event='http', route=label, status=status, duration_ms=round(elapsed*1000, 2))))

    @app.exception_handler(RequestValidationError)
    async def validation(request, exc):
        return JSONResponse(status_code=422, content={'detail':[
            {'loc':list(e['loc']), 'type':e['type'], 'msg':e['msg']} for e in exc.errors()]})

    @app.get('/')
    def index(): return FileResponse('web/index.html')

    @app.get('/health')
    def health(): return {'status':'ok', 'model_loaded':True, 'version':'2.0.0'}

    @app.get('/openapi.json', dependencies=[Depends(auth)])
    def schema(): return app.openapi()

    @app.get('/model', dependencies=[Depends(auth)])
    def model(): return app.state.detector.info

    @app.get('/metrics', dependencies=[Depends(auth)])
    def metrics(): return Response(generate_latest(registry), media_type=CONTENT_TYPE_LATEST)

    def predict_bytes(data, confidence):
        try:
            result = app.state.detector.predict(data, confidence)
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc
        except Exception as exc:
            errors.inc()
            log.exception('inference_failed')
            raise HTTPException(503, 'Inferencia no disponible') from exc
        inference.observe(result['inference_ms']/1000)
        detected.inc(result['count'])
        return result

    @app.post('/predict', dependencies=[Depends(auth)])
    def predict(image: UploadFile = File(...), confidence: float = Form(.25, ge=.05, le=.95)):
        return predict_bytes(image.file.read(5*1024*1024+1), confidence)

    @app.post('/reports', dependencies=[Depends(auth)], status_code=201)
    def report(image: UploadFile = File(...), latitude: float = Form(..., ge=-90, le=90, allow_inf_nan=False),
               longitude: float = Form(..., ge=-180, le=180, allow_inf_nan=False),
               street: str = Form(..., min_length=3, max_length=120), main_road: bool = Form(False)):
        if not street.strip(): raise HTTPException(422, 'Calle requerida')
        data = image.file.read(5*1024*1024+1)
        result = predict_bytes(data, .25)
        if not result['count']:
            raise HTTPException(422, 'No hay candidatos al umbral 0.25; use /predict para revisar')
        try:
            record = app.state.store.add(hashlib.sha256(data).hexdigest(), latitude, longitude,
                                         street.strip(), main_road, result)
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc
        return {**record, 'prediction':result, 'validation':'pendiente de revisión humana'}

    @app.get('/tickets', dependencies=[Depends(auth)])
    def tickets(): return app.state.store.list()

    @app.patch('/tickets/{ticket_id}', dependencies=[Depends(auth)])
    def update(ticket_id: int, body: TicketUpdate):
        if not app.state.store.update(ticket_id, body.status): raise HTTPException(404, 'Ticket no encontrado')
        return {'ticket_id':ticket_id, 'status':body.status}

    return app


app = create_app()
