import io
from pathlib import Path
import pytest
from PIL import Image
from fastapi.testclient import TestClient
from app.main import create_app
from app.detector import Detector, decode_image, iou, nms
from app.store import Store, distance_m
import numpy as np

HEADERS={'X-API-Key':'test-only-'+40*'x'}
SAMPLE=sorted(Path('samples').glob('*.jpg'))[0]


@pytest.fixture(scope='session')
def detector(): return Detector()


@pytest.fixture
def client(detector, tmp_path, monkeypatch):
    monkeypatch.setenv('API_KEY',HEADERS['X-API-Key'])
    with TestClient(create_app(detector, tmp_path/'test.db')) as c:
        yield c


def test_missing_key_startup(monkeypatch):
    monkeypatch.delenv('API_KEY',raising=False)
    with pytest.raises(RuntimeError):
        with TestClient(create_app()): pass


@pytest.mark.parametrize('route',['/metrics','/model','/tickets','/openapi.json'])
def test_protected_routes(client,route):
    assert client.get(route).status_code==401
    assert client.get(route,headers={'X-API-Key':'bad'}).status_code==401


def test_public_health_ui(client):
    assert client.get('/health').json()['model_loaded']
    assert 'SinBachesAPP' in client.get('/').text


def test_inference_real(client):
    r=client.post('/predict',headers=HEADERS,files={'image':('sample.jpg',SAMPLE.read_bytes(),'image/jpeg')})
    assert r.status_code==200
    result=r.json()
    assert result['pretrained'] and result['count']>0
    for d in result['detections']:
        assert .25<=d['confidence']<=1
        x1,y1,x2,y2=d['box_xyxy']
        assert 0<=x1<x2<=result['image_width']
        assert 0<=y1<y2<=result['image_height']


@pytest.mark.parametrize('value',['0','1','NaN','text'])
def test_bad_confidence(client,value):
    r=client.post('/predict',headers=HEADERS,files={'image':('x.jpg',SAMPLE.read_bytes())},data={'confidence':value})
    assert r.status_code==422


def test_invalid_image(client):
    assert client.post('/predict',headers=HEADERS,files={'image':('bad.jpg',b'not an image')}).status_code==422


def test_body_limit(client):
    assert client.post('/predict',headers=HEADERS,content=b'x'*(6*1024*1024+1)).status_code==413


def test_image_limit():
    with pytest.raises(ValueError): decode_image(b'x'*(5*1024*1024+1))
    b=io.BytesIO();Image.new('RGB',(16,16)).save(b,format='PNG')
    with pytest.raises(ValueError): decode_image(b.getvalue())


def test_duplicate_and_workflow(client):
    payload=dict(latitude='-13.53',longitude='-71.92',street='Avenida de prueba',main_road='true')
    files={'image':('sample.jpg',SAMPLE.read_bytes(),'image/jpeg')}
    r=client.post('/reports',headers=HEADERS,data=payload,files=files)
    assert r.status_code==201
    ticket=r.json()['ticket_id']
    assert client.post('/reports',headers=HEADERS,data=payload,files=files).status_code==409
    listed=client.get('/tickets',headers=HEADERS).json()
    assert listed[0]['status']=='pendiente' and listed[0]['reports']==1
    assert listed[0]['priority']=='alta'
    assert client.patch(f'/tickets/{ticket}',headers=HEADERS,json={'status':'validado'}).status_code==200
    assert client.patch(f'/tickets/{ticket}',headers=HEADERS,json={'status':'reparado'}).status_code==200
    assert client.patch('/tickets/999',headers=HEADERS,json={'status':'reparado'}).status_code==404


@pytest.mark.parametrize('field,value',[('latitude','91'),('longitude','181'),('latitude','NaN'),('street','')])
def test_report_validation(client,field,value):
    data=dict(latitude='-13.5',longitude='-71.9',street='Prueba')
    data[field]=value
    assert client.post('/reports',headers=HEADERS,data=data,files={'image':('x.jpg',SAMPLE.read_bytes())}).status_code==422


def test_geo_group_and_persistence(tmp_path):
    path=tmp_path/'persist.db';s=Store(path)
    a=s.add('a',-13.5,-71.9,'Una calle',False,{})
    b=s.add('b',-13.50001,-71.9,'Otra etiqueta',True,{})
    c=s.add('c',-13.6,-71.9,'Otra calle',False,{})
    assert a['ticket_id']==b['ticket_id']!=c['ticket_id']
    assert b['grouped']
    assert len(Store(path).list())==2
    assert s.list()[1]['reports']==2 and s.list()[1]['priority']=='alta'
    assert 0<distance_m(-13.5,-71.9,-13.50001,-71.9)<2


def test_post_repair_new_ticket(tmp_path):
    s=Store(tmp_path/'repair.db')
    a=s.add('a',0,0,'Calle',False,{})
    s.update(a['ticket_id'],'reparado')
    b=s.add('b',0,0,'Calle',False,{})
    assert a['ticket_id']!=b['ticket_id']


def test_iou_nms():
    assert iou([0,0,10,10],[0,0,10,10])==1
    assert iou([0,0,10,10],[20,20,30,30])==0
    boxes=np.array([[0,0,10,10],[1,1,11,11],[20,20,30,30]])
    assert nms(boxes,np.array([.9,.8,.7]))==[0,2]


def test_model_integrity(tmp_path):
    bad=tmp_path/'bad.onnx';bad.write_bytes(b'broken')
    with pytest.raises(RuntimeError,match='huella'): Detector(bad)


def test_repeatable(detector):
    a=detector.predict(SAMPLE.read_bytes());b=detector.predict(SAMPLE.read_bytes())
    assert a['detections']==b['detections']


def test_no_detection_does_not_create_report(client):
    b=io.BytesIO();Image.new('RGB',(640,640),(255,255,255)).save(b,format='PNG')
    r=client.post('/reports',headers=HEADERS,data=dict(latitude=0,longitude=0,street='Prueba'),
                  files={'image':('blank.png',b.getvalue())})
    assert r.status_code==422
    assert client.get('/tickets',headers=HEADERS).json()==[]


def test_metrics_and_schema(client):
    m=client.get('/metrics',headers=HEADERS)
    assert 'sinbaches_http_seconds' in m.text
    assert 'sinbaches_inference_errors_total' in m.text
    assert client.get('/openapi.json',headers=HEADERS).json()['info']['title']=='SinBachesAPP'
