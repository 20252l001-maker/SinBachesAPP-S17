"""Evaluación exploratoria real; diez imágenes test del conjunto del modelo."""
import csv
from datetime import datetime, timezone
import importlib.metadata
import json
from pathlib import Path
import platform
import statistics
from PIL import Image, ImageDraw
from app.detector import Detector, iou

out=Path('evidence');out.mkdir(exist_ok=True)
detector=Detector()
results=[];details=[]
for path in sorted(Path('samples').glob('*.jpg')):
    prediction=detector.predict(path.read_bytes(),.25)
    w,h=prediction['image_width'],prediction['image_height']
    labels=[]
    for line in path.with_suffix('.txt').read_text().splitlines():
        if line.strip():
            cls,x,y,bw,bh=map(float,line.split())
            labels.append([(x-bw/2)*w,(y-bh/2)*h,(x+bw/2)*w,(y+bh/2)*h])
    matched=set();tp=0
    for det in sorted(prediction['detections'],key=lambda d:-d['confidence']):
        options=[(iou(det['box_xyxy'],box),j) for j,box in enumerate(labels) if j not in matched]
        best=max(options,default=(0,-1))
        if best[0]>=.5:
            tp+=1;matched.add(best[1])
    results.append(dict(image=path.name,ground_truth=len(labels),predictions=prediction['count'],
                        true_positive=tp,false_positive=prediction['count']-tp,false_negative=len(labels)-tp,
                        inference_ms=prediction['inference_ms']))
    details.append(dict(image=path.name,ground_truth_boxes=labels,prediction=prediction))
    image=Image.open(path).convert('RGB');draw=ImageDraw.Draw(image)
    for box in labels: draw.rectangle(box,outline='#21bb69',width=2)
    for det in prediction['detections']:
        box=det['box_xyxy'];draw.rectangle(box,outline='#ed9226',width=3)
        draw.text((box[0],max(0,box[1]-12)),f"{det['confidence']:.2f}",fill='#d34f00')
    image.save(out/('prediction_'+path.name))
with (out/'evaluation.csv').open('w',newline='',encoding='utf-8') as f:
    writer=csv.DictWriter(f,fieldnames=results[0].keys());writer.writeheader();writer.writerows(results)
totals={k:sum(r[k] for r in results) for k in ('ground_truth','predictions','true_positive','false_positive','false_negative')}
tp,fp,fn=(totals[k] for k in ('true_positive','false_positive','false_negative'))
summary=dict(images=len(results),**totals,precision=tp/(tp+fp) if tp+fp else 0,
             recall=tp/(tp+fn) if tp+fn else 0,f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0,
             confidence=.25,matching_iou=.5,nms_iou=.45,
             mean_ms=statistics.mean(r['inference_ms'] for r in results),
             scope='Primeras 10 imagenes test por nombre del dataset declarado por el modelo; sin independencia acreditada; no es mAP ni validacion en Cusco',
             overlay='Verde: anotacion de referencia. Naranja: prediccion. No son capturas de una aplicacion en nube.')
(out/'evaluation_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
(out/'evaluation_details.json').write_text(json.dumps(details,indent=2),encoding='utf-8')
# Medición estable sobre una fotografía fija; calentamiento excluido.
sample=sorted(Path('samples').glob('*.jpg'))[0].read_bytes()
detector.predict(sample)
times=[detector.predict(sample)['inference_ms'] for _ in range(20)]
(out/'benchmark.json').write_text(json.dumps(dict(samples=20,warmup=1,mean_ms=statistics.mean(times),
    median_ms=statistics.median(times),p95_ms=sorted(times)[18],raw_ms=times,
    mode='CPU local secuencial; preprocesado inferencia y NMS; no mide red'),indent=2),encoding='utf-8')
(out/'environment.json').write_text(json.dumps(dict(executed_at_utc=datetime.now(timezone.utc).isoformat(),
    python=platform.python_version(),platform=platform.platform(),
    dependencies={name:importlib.metadata.version(name) for name in ('fastapi','uvicorn','pydantic','numpy','onnxruntime','Pillow','python-multipart','pytest','httpx','prometheus-client')},
    docker='No instalado en equipo local; construccion pendiente',cloud='Pendiente de cuenta y despliegue real',
    hardware='CPUExecutionProvider, un hilo de inferencia'),indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
