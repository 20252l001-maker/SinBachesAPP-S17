"""Descarga fijada por revision y verifica SHA256 antes de usar ONNX."""
import hashlib
import json
from pathlib import Path
import urllib.request

root=Path(__file__).resolve().parents[1]
info=json.loads((root/'models/model.json').read_text(encoding='utf-8'))
path=root/'models/pothole.onnx'
if path.exists() and hashlib.sha256(path.read_bytes()).hexdigest()==info['sha256']:
    print('Modelo existente verificado')
else:
    url=f"https://huggingface.co/{info['repo_id']}/resolve/{info['revision']}/{info['filename']}"
    temp=path.with_suffix('.download')
    try:
        with urllib.request.urlopen(url,timeout=180) as response, temp.open('wb') as output:
            while chunk:=response.read(1024*1024):output.write(chunk)
        if hashlib.sha256(temp.read_bytes()).hexdigest()!=info['sha256']:
            raise RuntimeError('SHA256 no coincide: se rechaza el modelo')
        temp.replace(path)
    finally:
        if temp.exists():temp.unlink()
    print('Modelo descargado y verificado')
