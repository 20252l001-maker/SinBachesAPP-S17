import sys
import time
import urllib.request

base=sys.argv[1].rstrip('/')
for _ in range(60):
    try:
        with urllib.request.urlopen(base+'/health',timeout=2) as r:
            assert r.status==200
            print(r.read().decode())
            break
    except OSError:
        time.sleep(1)
else:
    raise SystemExit('El servicio no inició')
