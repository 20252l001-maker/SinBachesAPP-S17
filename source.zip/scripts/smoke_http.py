"""Arranque real de Uvicorn, peticiones de inferencia y captura de métricas."""
import json
import os
from pathlib import Path
import secrets
import socket
import subprocess
import sys
import tempfile
import time
import httpx

with tempfile.TemporaryDirectory(prefix='sinbaches_http_') as temp:
    key=secrets.token_hex(32)
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    env={**os.environ,'API_KEY':key,'DB_PATH':str(Path(temp)/'test.db')}
    with Path('evidence/uvicorn.log').open('w',encoding='utf-8') as log:
        proc=subprocess.Popen([sys.executable,'-m','uvicorn','app.main:app','--host','127.0.0.1','--port',str(port),
                               '--log-config','app/logging.json'],env=env,stdout=log,stderr=log)
        try:
            with httpx.Client(base_url=f'http://127.0.0.1:{port}',timeout=30) as client:
                for _ in range(100):
                    try:
                        health=client.get('/health')
                        if health.status_code==200:break
                    except httpx.HTTPError:pass
                    time.sleep(.1)
                else: raise RuntimeError('Uvicorn no inició')
                photo=sorted(Path('samples').glob('*.jpg'))[0].read_bytes()
                auth={'X-API-Key':key}
                result=client.post('/predict',headers=auth,files={'image':('sample.jpg',photo,'image/jpeg')})
                denied=client.post('/predict',files={'image':('sample.jpg',photo,'image/jpeg')})
                report=client.post('/reports',headers=auth,files={'image':('sample.jpg',photo,'image/jpeg')},
                    data=dict(latitude=-13.53,longitude=-71.92,street='Ubicacion de prueba'))
                metrics=client.get('/metrics',headers=auth)
                assert result.status_code==200 and denied.status_code==401 and report.status_code==201
                Path('evidence/http_smoke.json').write_text(json.dumps(dict(transport='Uvicorn HTTP real por loopback',
                    health=health.json(),predict_status=result.status_code,unauthenticated_status=denied.status_code,
                    report_status=report.status_code,prediction=result.json(),report=report.json()),indent=2),encoding='utf-8')
                Path('evidence/metrics.prom').write_text(metrics.text,encoding='utf-8')
                print(json.dumps(dict(predict=result.status_code,unauthenticated=denied.status_code,report=report.status_code)))
        finally:
            proc.terminate()
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:proc.kill();proc.wait()
